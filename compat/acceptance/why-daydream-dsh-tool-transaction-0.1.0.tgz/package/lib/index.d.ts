/**
 * Saga-style compensating transactions for DeepSeek Harness.
 * Registers a `ctx.transaction` capability service: transactional step
 * execution with reverse-order compensation. Consumers (tools, workflows,
 * other plugins) begin a transaction, add named steps with `execute` +
 * `compensate`, then commit or roll back.
 *
 * This is NOT distributed ACID: it is a Saga-style compensating transaction —
 * compensation is best-effort, and a failed compensation yields
 * `ROLLBACK_PARTIAL` with per-step lifecycle events for manual resolution.
 *
 * @module @why-daydream/dsh-tool-transaction
 */
import { Service, type Context } from '@deepseek-ai/cordis';
export declare const name = "tool-transaction";
/** Plugin config: per-tool effect classification. */
export interface Config {
    /**
     * Per-tool effect classification. Tools not listed default to
     * `compensatable` when a `compensate` is provided and `reversible` when the
     * step declares no compensation. `irreversible` steps are denied at
     * step-join time by default policy.
     */
    effects?: Record<string, ToolEffect>;
}
/** Side-effect classification of a tool. */
export type ToolEffect = 'read-only' | 'reversible' | 'compensatable' | 'irreversible';
/**
 * Fail-loud validation of the plugin config: every configured effect value
 * must be a known classification, and only tools named in the config are
 * classified. Throws at plugin load on invalid entries.
 * @param config - plugin config to validate.
 */
export declare function validateConfig(config: Config | undefined): void;
/** Transaction lifecycle state. */
export type TransactionState = 'ACTIVE' | 'COMMITTED' | 'ROLLING_BACK' | 'ROLLED_BACK' | 'ROLLBACK_PARTIAL';
/** Lifecycle event payload shared by every `transaction/*` event. */
export interface TransactionEventData {
    /** Monotonic transaction id. */
    readonly id: number;
    /** Step name when the event concerns one step. */
    readonly step?: string;
    /** Error that failed a step or compensation. */
    readonly error?: unknown;
    /** Final state carried by `transaction/rollback-end`. */
    readonly state?: Exclude<TransactionState, 'ACTIVE' | 'ROLLING_BACK'>;
}
/** Event names emitted by this plugin, for `ctx.emit<K extends keyof Events>`. */
export type TransactionEvent = 'transaction/start' | 'transaction/step-start' | 'transaction/step-committed' | 'transaction/step-failed' | 'transaction/rollback-start' | 'transaction/compensation-start' | 'transaction/compensation-done' | 'transaction/compensation-failed' | 'transaction/rollback-end' | 'transaction/committed';
/**
 * One transactional step. `execute` produces a receipt; `compensate` undoes
 * the side effect and receives that step's own receipt. Compensation runs in
 * reverse order of committed steps.
 */
export interface TransactionStep<TReceipt = unknown> {
    /** Stable step name, used in lifecycle events and logs. */
    readonly name: string;
    /** Run the side-effectful operation; its return value is the receipt. */
    execute(): Promise<TReceipt>;
    /** Undo the side effect of `execute`'s receipt. Optional for reversible/read-only steps. */
    compensate?(receipt: TReceipt): Promise<void>;
}
/**
 * A running transaction: add steps, then commit or roll back.
 * After `commit()` or `rollback()` settles, the transaction is closed and no
 * further steps may be added.
 */
export interface Transaction {
    /** Monotonic transaction id for logs and event correlation. */
    readonly id: number;
    /** Current lifecycle state. */
    readonly state: TransactionState;
    /** Execute one step and record its receipt for reverse-order compensation. */
    step<TReceipt = unknown>(step: TransactionStep<TReceipt>): Promise<TReceipt>;
    /** Commit: every added step stays; marks the transaction COMMITTED. */
    commit(): Promise<void>;
    /** Roll back: compensate committed steps in reverse order. */
    rollback(): Promise<void>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        transaction: TransactionService;
    }
    interface Events {
        'transaction/start'(data: TransactionEventData): void;
        'transaction/step-start'(data: TransactionEventData): void;
        'transaction/step-committed'(data: TransactionEventData): void;
        'transaction/step-failed'(data: TransactionEventData): void;
        'transaction/rollback-start'(data: TransactionEventData): void;
        'transaction/compensation-start'(data: TransactionEventData): void;
        'transaction/compensation-done'(data: TransactionEventData): void;
        'transaction/compensation-failed'(data: TransactionEventData): void;
        'transaction/rollback-end'(data: TransactionEventData): void;
        'transaction/committed'(data: TransactionEventData): void;
    }
}
/**
 * Cordis service exposing Saga-style transactions on `ctx.transaction`.
 * The service itself is stateless; each `begin()` creates an isolated
 * transaction with its own step log and lifecycle state.
 */
export declare class TransactionService extends Service {
    private readonly config;
    private nextId;
    constructor(ctx: Context, config: Config);
    /**
     * Open a new transaction. The returned handle is the only way to add steps
     * or settle the transaction; two transactions never share step state.
     * @returns a fresh ACTIVE transaction.
     */
    begin(): Transaction;
    /**
     * Convenience runner: begin, execute each step in order, commit; on any
     * failure roll back (reverse-order compensation) and rethrow the error.
     * @param steps - steps executed sequentially in the given order.
     * @returns the settled transaction (COMMITTED on success).
     */
    run(steps: readonly TransactionStep<unknown>[]): Promise<Transaction>;
}
/**
 * Plugin entry: validate the config, then register the `ctx.transaction`
 * service. Invalid effect classifications throw at load time (fail-loud);
 * an absent config row is treated as an empty config.
 * @param ctx - Cordis context to register the service on.
 * @param config - plugin config (effect classification); defaults to empty.
 */
export declare function apply(ctx: Context, config?: Config): void;
